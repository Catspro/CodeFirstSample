﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodeFirstApproachCatspro
{
    class Course
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
    }
}
