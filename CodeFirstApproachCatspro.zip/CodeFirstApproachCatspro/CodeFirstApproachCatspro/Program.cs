﻿using System;

namespace CodeFirstApproachCatspro
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var db = new StudentDb()) // object of Database ( context class )  
            {
                Student stu = new Student(); // student table object  

                Console.WriteLine("Name : ");
                stu.Name = Console.ReadLine(); // use object.Property to assign data.  

                // Data Insertion into database.  
                db.Students.Add(stu);
                db.SaveChanges();
                Console.WriteLine("Data has been inserted successfully");





                using (var context = new StudentDb())
                {

                    var std = new Student()
                    {
                        Name = "Bill"
                    };

                    context.Students.Add(std);
                    context.SaveChanges();
                }
            }
        }
    }
}
